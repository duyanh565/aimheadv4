BẢN FINAL ĐÃ SỬA:
- Không còn lỗi "key thành công nhưng vẫn báo lỗi".
- Chỉ còn 1 luồng kiểm tra key qua Netlify Function.
- Key VIP có type: "vip" sẽ mở thẳng tab VIP.
- Lưu số máy đã dùng key: devices, udids, usedCount.
- Nút tạo key/admin vẫn dùng được với firestore.rules kèm theo.

CÁCH DÙNG:
1. Upload lại toàn bộ project lên Netlify.
2. Netlify phải có Environment Variable:
   FIREBASE_SERVICE_ACCOUNT
3. Vào Deploys -> Trigger deploy -> Clear cache and deploy site.
4. Dán firestore.rules vào Firebase -> Firestore Database -> Rules -> Publish.
5. Key VIP trong Firestore:
   type: "vip"
   maxDevices: 1 hoặc số máy muốn cho dùng
   used: false
   udid: ""
