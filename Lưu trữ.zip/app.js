// app.js sạch: không kiểm tra key ở đây để tránh lỗi chồng với legacy.js.
// Key chỉ được kiểm tra trong legacy.js qua Netlify Function.

// ===== SINGLE CLEAN BEEP =====
const AIMHEAD_BEEP = new Audio("./clean-one-beep.mp3");
AIMHEAD_BEEP.preload = "auto";
AIMHEAD_BEEP.volume = 1;
AIMHEAD_BEEP.load();

let aimheadBeepLock = false;
let aimheadLastBeep = 0;

function aimheadPlayBeep(){
  const now = performance.now();
  if(aimheadBeepLock || now - aimheadLastBeep < 650) return;

  aimheadBeepLock = true;
  aimheadLastBeep = now;

  try{
    AIMHEAD_BEEP.pause();
    AIMHEAD_BEEP.currentTime = 0;
    AIMHEAD_BEEP.play().catch(()=>{});
  }catch(e){}

  setTimeout(()=> aimheadBeepLock = false, 650);
}

document.addEventListener("click", function(event){
  const target = event.target.closest("button, .link-btn, .tab-btn, .toggle-action, .color-btn");
  if(!target) return;
  aimheadPlayBeep();
}, {capture:true, passive:true});
