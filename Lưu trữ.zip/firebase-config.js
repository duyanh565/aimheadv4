export const firebaseConfig = {
  apiKey: "AIzaSyC6S3RZy3y7_dnqxBtVJ0jp71G9BLq0VII",
  authDomain: "newappkey-fa1d9.firebaseapp.com",
  projectId: "newappkey-fa1d9",
  storageBucket: "newappkey-fa1d9.firebasestorage.app",
  messagingSenderId: "687660237529",
  appId: "1:687660237529:web:79b2c5f3f628b9ce92b4c8",
  measurementId: "G-9QGDJRTXCQ"
};
