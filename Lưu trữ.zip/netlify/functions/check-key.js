const admin = require("firebase-admin");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(
      JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)
    )
  });
}

const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;

function isExpired(expireAt) {
  if (!expireAt || expireAt === "forever") return false;

  if (expireAt.toDate && typeof expireAt.toDate === "function") {
    return expireAt.toDate() < new Date();
  }

  const n = Number(expireAt);
  if (!Number.isNaN(n)) return n < Date.now();

  const d = new Date(expireAt);
  if (!Number.isNaN(d.getTime())) return d < new Date();

  return false;
}

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body || "{}");
    const key = String(body.key || "").trim();
    const udid = String(body.udid || "").trim();

    if (!key) {
      return {
        statusCode: 200,
        body: JSON.stringify({ ok:false, message:"missing_key" })
      };
    }

    const ref = db.collection("keys").doc(key);
    const snap = await ref.get();

    if (!snap.exists) {
      return {
        statusCode: 200,
        body: JSON.stringify({ ok:false, message:"key_not_found" })
      };
    }

    const data = snap.data() || {};
    const type = String(data.type || "normal").trim().toLowerCase();
    const maxDevices = Math.max(1, Number(data.maxDevices || data.maxDevice || 1));

    if (isExpired(data.expireAt)) {
      return {
        statusCode: 200,
        body: JSON.stringify({ ok:false, message:"expired" })
      };
    }

    const devices = Array.isArray(data.devices)
      ? data.devices.map(String)
      : Array.isArray(data.udids)
        ? data.udids.map(String)
        : [];

    const legacyUdid = data.udid ? String(data.udid) : "";

    const usedSet = new Set(devices);
    if (legacyUdid) usedSet.add(legacyUdid);

    const alreadyUsed = udid && usedSet.has(udid);

    if (udid && !alreadyUsed && usedSet.size >= maxDevices) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          ok:false,
          message:"used_other_device",
          usedCount: usedSet.size,
          maxDevices
        })
      };
    }

    if (udid && !alreadyUsed) {
      usedSet.add(udid);

      await ref.set({
        used: true,
        udid: data.udid || udid,
        devices: Array.from(usedSet),
        udids: Array.from(usedSet),
        usedCount: usedSet.size,
        lastUsedAt: FieldValue.serverTimestamp(),
        activatedAt: data.activatedAt || FieldValue.serverTimestamp()
      }, { merge:true });
    } else if (udid) {
      await ref.set({
        used: true,
        lastUsedAt: FieldValue.serverTimestamp()
      }, { merge:true });
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        ok:true,
        key,
        type,
        vip: type === "vip",
        isVip: type === "vip",
        usedCount: udid ? usedSet.size : Math.max(1, Number(data.usedCount || usedSet.size || 1)),
        maxDevices
      })
    };

  } catch (e) {
    console.error(e);
    return {
      statusCode: 500,
      body: JSON.stringify({
        ok:false,
        message:"server_error",
        error:String(e.message || e)
      })
    };
  }
};
